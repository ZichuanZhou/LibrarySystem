CREATE database if not EXISTS library;

DROP TABLE Item_Return; 

DROP TABLE Item_Borrow; 

DROP TABLE Operater; 

DROP TABLE Reader; 

DROP TABLE Item;



CREATE TABLE Item (

itemId			    INTEGER(7) 	unsigned      	NOT NULL		AUTO_INCREMENT,

itemType			VARCHAR(10)			NOT NULL,
    
bindingType         VARCHAR(30)         NOT NULL,

ISBN       			VARCHAR(30)	        NOT NULL,
    
name		    		VARCHAR(99) 	  		NOT NULL,
    
author           	VARCHAR(40)            DEFAULT NULL,

publisher	    	VARCHAR(40)	      	DEFAULT NULL,
    
years               VARCHAR(20)            DEFAULT NULL,
    
createDate              VARCHAR(20)               NOT NULL,

price	    			DOUBLE		      		DEFAULT NULL,

status				VARCHAR(12)    	    NOT NULL   DEFAULT 'Available',

location				VARCHAR(40)			DEFAULT NULL,
    
notes                   VARCHAR(199)            DEFAULT NULL, 
         
PRIMARY KEY (ItemId)

) ENGINE = INNODB;



CREATE TABLE Reader (

readerId				VARCHAR(20) 	     	NOT NULL,
    
name            		VARCHAR(30)       		NOT NULL, 
    
gender          		CHAR(1)             		NOT NULL,

DOB					DATE						DEFAULT NULL,

phoneNo		    VARCHAR(15)	        NOT NULL,

email	        		VARCHAR(30)       		NOT NULL,

address				VARCHAR(50)			DEFAULT NULL,

createDate			DATE               NOT NULL,
    
notes               VARCHAR(99)            DEFAULT NULL,
    
PRIMARY KEY (readerId)

) ENGINE = INNODB;



CREATE TABLE Operater (

operaterId          INTEGER(4) 	unsigned      	NOT NULL		AUTO_INCREMENT,
    
name		    		 VARCHAR(30) 	  		NOT NULL,

gender				 CHAR(1),

createDate			 DATE              NOT NULL,

phoneNo		    VARCHAR(15),

address				VARCHAR(50),
    
password				 VARCHAR(20)			NOT NULL,	

PRIMARY KEY (operaterId)

) ENGINE = INNODB;

insert into Operater (name,createDate,password) values ('zzc','2015-09-01','zzc');



CREATE TABLE Item_Borrow (

borrowId       	 INTEGER(10) 	unsigned      	NOT NULL		AUTO_INCREMENT,
    
readerId			 VARCHAR(20) 	 		NOT NULL, 
    
readerName          VARCHAR(30)       		NOT NULL, 

itemId        	 INTEGER(7) 	unsigned		NOT NULL,	
    
itemName            VARCHAR(50) 	  		NOT NULL,

operaterId       INTEGER(3)	unsigned		NOT NULL,
    
operaterName       VARCHAR(30) 	  		NOT NULL,

borrowTime	     DATE					NOT NULL,

backTime		  DATE					NOT NULL,
    
isBack          VARCHAR(1)        NOT NULL   DEFAULT 'N',

PRIMARY KEY (borrowId), 

FOREIGN KEY (readerId) REFERENCES Reader (readerId)
	ON UPDATE CASCADE ON DELETE CASCADE,
    
FOREIGN KEY (itemId) REFERENCES Item (itemId)
	ON UPDATE CASCADE ON DELETE CASCADE,

FOREIGN KEY (operaterId) REFERENCES Operater (operaterId)
	ON UPDATE CASCADE ON DELETE CASCADE

) ENGINE = INNODB;



CREATE TABLE Item_Return (

returnId       	 INTEGER(10) 	unsigned      	NOT NULL		AUTO_INCREMENT,
    
readerId			 VARCHAR(20)			NOT NULL, 
    
readerName          VARCHAR(30)       		NOT NULL, 

itemId            INTEGER(7) 	unsigned    	NOT NULL,	
    
itemName            VARCHAR(50) 	  		NOT NULL,

operaterId       INTEGER(3)		unsigned	NOT NULL,

operaterName       VARCHAR(30) 	  		NOT NULL,    
    
backTime		  DATE					NOT NULL,

PRIMARY KEY (returnId), 

FOREIGN KEY (readerId) REFERENCES Reader (readerId)
	ON UPDATE CASCADE ON DELETE CASCADE,
    
FOREIGN KEY (itemId) REFERENCES Item (itemId)
	ON UPDATE CASCADE ON DELETE CASCADE,

FOREIGN KEY (operaterId) REFERENCES Operater (operaterId)
	ON UPDATE CASCADE ON DELETE CASCADE

) ENGINE = INNODB;
