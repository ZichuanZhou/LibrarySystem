insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover', 'B10001', '我的故乡', '老王', '中华出版社', '1998', '2005',10.5,'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('DVD', 'Simple Case', 'D10001', 'Playground','Tom & Jerry','Entertainment', '2010', '2011',15,'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover', 'B10002', 'Java Application','Trent','Flinders Uni', '2008', '2008',33,'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Copy','B10003', 'Web Development', 'Marius', 'Flinders Uni', '2010', '2015',10.5,'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover', 'B10004', 'Software Engineering', 'Shaowen','Flinders Uni', '2013', '2014', 12.6, 'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover', 'B10005','我的故乡','老王','中华出版社', '1998', '2005',10.5,'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover','B10006','Life of PI','Anndi','Global Culture', '2009', '2015',63.5,'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('DVD', 'Hard Cover','D20001','My heart will go on','Silin','Voice of Aussie', '2009', '2011', 10.5, 'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover', 'B10007', 'Statistic', 'Defi','Uni SA', '2005', '2005', 10.5, 'Available');
insert into item (itemType, bindingType, ISBN, name, author, publisher, years, createDate, price, status) values('Book', 'Hard Cover', 'B10009', 'DataBase', 'John','Carb & Fish', '2013', '2014', 10.5, 'Available');



insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('Ste0015', 'Steven', 'M', '0425678941', '123@456.com', '2 condada ave, park holme, 5043', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('Dua9832', '段誉', 'M', '0889869754', '123@456.com', '中国 大理', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('wei0001', '韦小宝', 'M', '3654987512', '123@456.com', '大清 北京 故宫', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('Jue238', 'Julia', 'F', '0425678941', 'Julia@hotmail.com', '3 Street Ave, Newton', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('zhang98', '张三丰', 'M', '0425678941', '123@456.com', '中国 湖北 武当山', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('1204675', 'Monica', 'F', '0324568951', '123@456.com', '2 condada ave, park holme, 5043', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('21548562', 'Annie', 'F', '0456923156', '123@456.com', 'Mount Campuss', '2014-11-12');
insert into reader (readerId, name, gender, phoneNo, email, address, createDate) values ('ui889', 'Connie', 'F', '0425678941', '123@456.com', 'Wendy Point', '2014-11-12');





