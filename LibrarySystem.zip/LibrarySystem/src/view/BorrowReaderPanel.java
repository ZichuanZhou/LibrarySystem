/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import control.Dao;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.ItemBorrow;
import model.Reader;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class BorrowReaderPanel extends JPanel{
    
    private Component component = null;
    private String searchInfo = null;
    private BorrowFrame bf = null;
    private String type = null;
    private Object[][] rowData; 
    private String[] columnNames = {" ","ID","Name","Phone","Email"};
    String[] columnNames1 = {"Borrow Date", "Item ID", "Item Name", "Reader ID", "Reader Name", "Return Date", "Operater ID", "Operater Name"};
    private JScrollPane jsp;
    private JTable jt;
    
    /**
     * Constructor with parameters, after item search, information will 
     * be filled in these jTextFileds
     * @param component
     * @param isbn
     * @param name
     * @param author
     * @param publisher 
     */
    public BorrowReaderPanel(BorrowFrame bf){
        this.bf = bf; 
    }

    public JTable tableUpdate(){
        searchInfo = bf.getjTextFieldReaderSearch().getText().trim();
        type = bf.getjComboBoxReader().getSelectedItem().toString();
        
        if(!searchInfo.isEmpty()){
            rowData = getSelect(Dao.findReaderBy(searchInfo,type));
        } else{
            rowData = getSelect(Dao.selectReader());
        }        
        jt = new JTable(rowData,columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        //set the width of first column of jt
        jt.getColumnModel().getColumn(0).setMaxWidth(10);
        //set the size for jt
        jt.setPreferredScrollableViewportSize(new Dimension(300,135));
        jt.setAutoCreateRowSorter(true);
        jt.getTableHeader().setReorderingAllowed(false);
        jt.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2){
                    int selRow = jt.getSelectedRow();
                    String id = jt.getValueAt(selRow, 1).toString();
                    String name = jt.getValueAt(selRow, 2).toString();
                    String phone = jt.getValueAt(selRow, 3).toString();
                    String email = jt.getValueAt(selRow, 4).toString();
                    bf.getjTextFieldReaderID().setText(id);
                    bf.getjTextFieldReaderName().setText(name);
                    bf.getjTextFieldReaderPhone().setText(phone);
                    bf.getjTextFieldReaderEmail().setText(email);
                    BorrowReaderPanel.this.setVisible(false);
                    
                    Object[][] rowData1 = getFileStates(Dao.selectBorrow(bf.getjTextFieldReaderID().getText()));
                    bf.getjTableList().setModel(new DefaultTableModel(
                        rowData1, columnNames1
                    ));
                }
            }
        });
        return jt;
    }

    /**
     * initialize the position of the item panel, the method makes this panel 
     * reusable in future, add event listener for the component which called this
     * method
     * 
     */
    public void initPanel(){
        if(component instanceof JComponent){
            JComponent j = (JComponent)component;
            int x = j.getX();
            int y = j.getY();
            int h = j.getHeight();
//            this.setComponent(component);
//            this.setBorder(BorderFactory.createEmptyBorder());
            this.setBounds(x+407, y+h+72, 320, 166);
            this.setVisible(false);
            jt = this.tableUpdate();
//            jt.setBorder(BorderFactory.createEmptyBorder());
            jsp = new JScrollPane(jt);
            jsp.setBounds(2, 2, 300, 135); 
            this.add(jsp);
        }
    }
  
    /**
     * get item borrow list from Dao, convert it into object[][] fill in jTable
     * @param list
     * @return 
     */
    private Object[][] getFileStates(ArrayList<ItemBorrow> list){
        Object[][] results = new Object[list.size()][9];
        for(int i=0; i<list.size(); i++){
            ItemBorrow borrow = (ItemBorrow)list.get(i);
            results[i][0] = borrow.getBorrowDate();
            results[i][1] = borrow.getItemID();
            results[i][2] = borrow.getItemName();
            results[i][3] = borrow.getReaderID();
            results[i][4] = borrow.getReaderName();
            results[i][5] = borrow.getReturnDate();
            results[i][6] = borrow.getOperaterID();
            results[i][7] = borrow.getOperaterName();
        }
        return results;
    }        
    
    /**
     * get item list from Dao, convert it into object[][] fill in jt
     * @param list
     * @return 
     */
    private Object[][] getSelect(ArrayList list) {
        Object[][] s = new Object[list.size()][5];
        for (int i = 0; i < list.size(); i++){
                Reader reader = (Reader) list.get(i);
                s[i][0] = "";
                s[i][1] = reader.getId();
                s[i][2] = reader.getName();
                s[i][3] = reader.getPhoneNo();
                s[i][4] = reader.getEmail();
        }
        return s;
    }
    
    public Object getComponent() {
        return component;
    }
    
    public void setBf(BorrowFrame bf) {
        this.bf = bf;
    }
    
    public void setComponent() {
        this.component = bf.getjTextFieldReaderSearch();
    }  

    public void setJTable(JTable jt) {
        this.jt = jt;
    }

    public JScrollPane getJScrollPane() {
        return jsp;
    }

    public void setJScrollPane(JScrollPane jsp) {
        this.jsp = jsp;
    }

    public JTable getJTable() {
        return jt;
    }
}
