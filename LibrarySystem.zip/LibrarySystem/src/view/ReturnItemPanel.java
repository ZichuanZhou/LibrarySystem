/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import control.Dao;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Item;
import model.ItemBorrow;
import model.Reader;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class ReturnItemPanel extends JPanel{
    
    private Component component = null;
    private String searchInfo = null;
    private String readerId = null;
    private ReturnFrame rf = null;
    private String type = null;
    private Object[][] rowData; 
    private String[] columnNames = {" ","ID","ISBN","Name","Author"};
    private String[] columnNames2 = {"Borrow Date", "Item ID", "Item Name", "Reader ID", "Reader Name", "Return Date", "Operater ID", "Operater Name"};
    private JScrollPane jsp;
    private JTable jt;
    
    /**
     * Constructor with parameters, after item search, information will 
     * be filled in these jTextFileds
     * @param component
     * @param isbn
     * @param name
     * @param author
     * @param publisher 
     */
    public ReturnItemPanel(ReturnFrame rf){
        this.rf = rf; 
    }
    
    public JTable tableUpdate(){
        searchInfo = rf.getjTextFieldItemSearch().getText().trim();
        readerId = rf.getjTextFieldReaderID().getText();
        type = rf.getjComboBoxItem().getSelectedItem().toString();
        
        if(readerId.isEmpty()){
            if(searchInfo.isEmpty()){
                //only show the items which is Unavailable
                rowData = getSelect(Dao.selectItem("UA"));
            } else {
                //show unavailable items with keywords search
                rowData = getSelect(Dao.findItemBy(searchInfo,type,"UA"));
            } 
        } else { 
            if(searchInfo.isEmpty()){
                //only show the items which are borrowed by selected reader
                rowData = getSelect(Dao.selectItem("UA", readerId));
            }else{
                //show the items which are borrowed by selected reader with keywords search
                rowData = getSelect(Dao.findItemBy(searchInfo, type, "UA", readerId));
            }
        }
  
        jt = new JTable(rowData,columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        //set the width of first column of jTable
        jt.getColumnModel().getColumn(0).setMaxWidth(10);
        //set the size for jTable
        jt.setPreferredScrollableViewportSize(new Dimension(300,135));
        jt.setAutoCreateRowSorter(true);
        jt.getTableHeader().setReorderingAllowed(false);
        jt.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2){
                    int selRow = jt.getSelectedRow();
                    
                    String id = jt.getValueAt(selRow, 1).toString();
                    String isbn = jt.getValueAt(selRow, 2).toString();
                    String name = jt.getValueAt(selRow, 3).toString();
                    String author = jt.getValueAt(selRow, 4).toString();
                    
                    //fill item informatoin in ReturnFrame
                    rf.getjTextFieldItemISBN().setText(isbn);
                    rf.getjTextFieldItemName().setText(name);
                    rf.getjTextFieldItemAuthor().setText(author);
                    rf.getjTextFieldItemID().setText(id);
                    
                    
                    if(readerId.isEmpty()){
                        //reader's information who borrow selected item will be filled
                        //in ReturnFrame automatically
                        Reader reader = Dao.findReaderBy(id);
                        rf.getjTextFieldReaderID().setText(reader.getId());
                        rf.getjTextFieldReaderEmail().setText(reader.getEmail());
                        rf.getjTextFieldReaderName().setText(reader.getName());
                        rf.getjTextFieldReaderPhone().setText(reader.getPhoneNo());
                        
                        Object[][] rowData2 = ReturnFrame.getFileStates(
                            Dao.selectBorrow(reader.getId()));
                        
                        //update the item_borrow jTable in ReturnFrame
                        rf.getjTableList().setModel(new DefaultTableModel(
                            rowData2,columnNames2
                        ));                        
                    }
                    ReturnItemPanel.this.setVisible(false);
                }
            }
        });
        return jt;
    }

    /**
     * initialize the position of the item panel, the method makes this panel 
     * reusable in future, add event listener for the component which called this
     * method
     * 
     */
    public void initPanel(){
        if(component instanceof JComponent){
            JComponent j = (JComponent)component;
            int x = j.getX();
            int y = j.getY();
            int h = j.getHeight();
            this.setBounds(x+40, y+h+72, 320, 166);
            this.setVisible(false);
            
            jt = this.tableUpdate();
            jsp = new JScrollPane(jt);
            jsp.setBounds(2, 2, 300, 135); 
            this.add(jsp);
        }
    }
    
    /**
     * get item list from Dao, convert it into object[][] fill in this panel's jt.
     * @param list
     * @return 
     */
    private Object[][] getSelect(ArrayList list) {
        Object[][] s = new Object[list.size()][5];
        for (int i = 0; i < list.size(); i++){
                Item item = (Item) list.get(i);
                s[i][0] = "";
                s[i][1] = item.getId();
                s[i][2] = item.getIsbn();
                s[i][3] = item.getName();
                s[i][4] = item.getAuthor();
                
        }
        return s;
    }
         
    public Object getComponent() {
        return component;
    }
    
    public void setRf(ReturnFrame rf) {
        this.rf = rf;
    }
    
    public void setComponent() {
        this.component = rf.getjTextFieldItemSearch();
    }    
}
