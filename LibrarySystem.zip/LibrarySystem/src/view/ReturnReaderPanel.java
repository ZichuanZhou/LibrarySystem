/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import control.Dao;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.ItemBorrow;
import model.Reader;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class ReturnReaderPanel extends JPanel{
    
    private Component component = null;
    private String searchInfo = null;
    private String itemId = null;
    private ReturnFrame rf = null;
    private String type = null;
    private Object[][] rowData; 
    private String[] columnNames = {" ","ID","Name","Phone","Email"};
    private String[] columnNames2 = {"Borrow Date", "Item ID", "Item Name", "Reader ID", "Reader Name", "Return Date", "Operater ID", "Operater Name"};
    private JScrollPane jsp;
    private JTable jt;
    
    /**
     * Constructor with parameters, after item search, information will 
     * be filled in these jTextFileds
     * @param component
     * @param isbn
     * @param name
     * @param author
     * @param publisher 
     */
    public ReturnReaderPanel(ReturnFrame rf){
        this.rf = rf; 
        
    }

    
    public JTable tableUpdate(){
        searchInfo = rf.getjTextFieldReaderSearch().getText().trim();
        itemId = rf.getjTextFieldItemID().getText();
        type = rf.getjComboBoxReader().getSelectedItem().toString();
        
        if(itemId.isEmpty()){
            if(!searchInfo.isEmpty()){
                rowData = getSelect(Dao.findReaderBy(searchInfo,type));
            } else{
                rowData = getSelect(Dao.selectReader());
            }  
        } else{
            ArrayList<Reader> arr = new ArrayList();
            arr.add(Dao.findReaderBy(itemId));
            rowData = getSelect(arr);
        }
        
        jt = new JTable(rowData,columnNames){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        //set the width of first column of jt
        jt.getColumnModel().getColumn(0).setMaxWidth(10);
        //set the size for jt
        jt.setPreferredScrollableViewportSize(new Dimension(300,135));
        jt.setAutoCreateRowSorter(true);
        jt.getTableHeader().setReorderingAllowed(false);
        jt.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2){
                    int selRow = jt.getSelectedRow();
                    
                    String id = jt.getValueAt(selRow, 1).toString();
                    String name = jt.getValueAt(selRow, 2).toString();
                    String phone = jt.getValueAt(selRow, 3).toString();
                    String email = jt.getValueAt(selRow, 4).toString();
                    
                    //fill reader information in ReturnFrame
                    rf.getjTextFieldReaderID().setText(id);
                    rf.getjTextFieldReaderName().setText(name);
                    rf.getjTextFieldReaderPhone().setText(phone);
                    rf.getjTextFieldReaderEmail().setText(email);
                    
                    Object[][] rowData2 = ReturnFrame.getFileStates(
                        Dao.selectBorrow(rf.getjTextFieldReaderID().getText()));
                    
                    //update the item_borrow jTable in ReturnFrame
                    rf.getjTableList().setModel(new DefaultTableModel(
                        rowData2,columnNames2
                    ));
                    
                    ReturnReaderPanel.this.setVisible(false);
                }
            }
        });
        return jt;
    }

    /**
     * initialize the position of the item panel, the method makes this panel 
     * reusable in future, add event listener for the component which called this
     * method
     * 
     */
    public void initPanel(){
        if(component instanceof JComponent){
            JComponent j = (JComponent)component;
            int x = j.getX();
            int y = j.getY();
            int h = j.getHeight();
//            this.setComponent(component);
//            this.setBorder(BorderFactory.createEmptyBorder());
            this.setBounds(x+407, y+h+72, 320, 166);
            this.setVisible(false);
            jt = this.tableUpdate();
//            jt.setBorder(BorderFactory.createEmptyBorder());
            jsp = new JScrollPane(jt);
            jsp.setBounds(2, 2, 300, 135); 
            this.add(jsp);
        }
    }
    
    /**
     * get item list from Dao, convert it into object[][] fill in jt
     * @param list
     * @return 
     */
    private Object[][] getSelect(ArrayList list) {
        Object[][] s = new Object[list.size()][5];
        for (int i = 0; i < list.size(); i++){
                Reader reader = (Reader) list.get(i);
                s[i][0] = "";
                s[i][1] = reader.getId();
                s[i][2] = reader.getName();
                s[i][3] = reader.getPhoneNo();
                s[i][4] = reader.getEmail();
        }
        return s;
    }    
    
    public Object getComponent() {
        return component;
    }
    
    public void setBf(ReturnFrame rf) {
        this.rf = rf;
    }
    
    public void setComponent() {
        this.component = rf.getjTextFieldReaderSearch();
    }  

    public void setJTable(JTable jt) {
        this.jt = jt;
    }

    public JScrollPane getJScrollPane() {
        return jsp;
    }

    public void setJScrollPane(JScrollPane jsp) {
        this.jsp = jsp;
    }

    public JTable getJTable() {
        return jt;
    }    
}
