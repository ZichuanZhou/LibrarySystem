/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class OperaterValidation {
    String name, phone, password;

    public OperaterValidation(String name, String phone, String password) {
        this.name = name;
        this.phone = phone;
        this.password = password;
    }
    
    public boolean validateName(){
        String sql = "select *  from operater where name='" + name + "'";

        try {
            if(name.length()>0 && !Dao.executeQuery(sql).next()){ //if the result set has next(), mean this name has been used
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean validatePhone(){
        if(phone.length()==0 || phone.matches("[0-9]{8,12}")){
            return true;
        }
        return false;
    }
    
    public boolean validatePassword(){
        if(password.length()>0){
            return true;
        }
        return false;
    }
}
