/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 * Uses audioInputStream to play audio file
 * @author Zichuan Zhou
 */
public class PlaySound {

    
    public static void playSound(String str){
        
        AudioInputStream audio = null;
        try{
            audio = AudioSystem.getAudioInputStream(new File(str));
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch(Exception e) {
            e.printStackTrace();
        } finally{
            try {
                audio.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }    
    }
    
//    /**
//     *Plays an error sound. This is happening when there is an error or exception.
//     */
//    public static void errorSound() {
//        AudioInputStream audio = null;
//        try{
//            audio = AudioSystem.getAudioInputStream(new File("src/Sounds/error.wav"));
//            Clip clip = AudioSystem.getClip();
//            clip.open(audio);
//            clip.start();
//        } catch(Exception e) {
//            e.printStackTrace();
//        } finally{
//            try {
//                audio.close();
//            } catch (IOException ex) {
//                ex.printStackTrace();
//            }
//        }        
//    }
//    
//    /**
//     *Plays a sound when the file is loaded or indexed. It is triggered when load and index buttons are pressed.
//     * Also, when index and load are selected from the menu, this will be played.
//     */
//    public static void loadSound(){
//        AudioInputStream audio = null;
//        try{
//            audio = AudioSystem.getAudioInputStream(new File("src/Sounds/arme.wav"));
//            Clip clip = AudioSystem.getClip();
//            clip.open(audio);
//            clip.start();
//        } catch(Exception e) {
//            e.printStackTrace();
//        } finally{
//            try {
//                audio.close();
//            } catch (IOException ex) {
//                ex.printStackTrace();
//            }
//        }        
//    }
//    
//    /**
//     *Plays a sound for exiting the program. It is triggered when the exit button is triggered.
//     * Also, when exit is selected from the menu, this will be played.
//     */
//    public static void exitSound(){
//        AudioInputStream audio = null;
//        try{
//            audio = AudioSystem.getAudioInputStream(new File("src/Sounds/exit.wav"));
//            Clip clip = AudioSystem.getClip();
//            clip.open(audio);
//            clip.start();
//        } catch(Exception e) {
//            e.printStackTrace();
//        } finally{
//            try {
//                audio.close();
//            } catch (IOException ex) {
//                ex.printStackTrace();
//            }
//        }         
//    }    
}
