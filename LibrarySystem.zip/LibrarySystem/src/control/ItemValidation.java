/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *validate book information from BookAddFrame
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class ItemValidation {
    
    String isbn, name, price;

    public ItemValidation(String isbn, String name, String price) {
        this.isbn = isbn;
        this.name = name;
        this.price = price;
    }
    
    public boolean validateIsbn(){
        if(isbn.length() > 0){
            return true;
        } 
        return false;
    }
    
    public boolean validateName(){
        if(name.length() > 0){
            return true;
        }
        return false;
    }
    
    public boolean validatePrice(){
        try{
            Double.parseDouble(price);
        } catch(Exception e){
            return false;
        }
        return true;
    }
}
