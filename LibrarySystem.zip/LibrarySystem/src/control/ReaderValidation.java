/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 * validate reader information from ReaderAddFrame
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class ReaderValidation {
    
    String name, phone, email, DOB;

    public ReaderValidation(String name, String phone, String email, String DOB) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.DOB = DOB;
    }
    
    public boolean validateName(){
        if(name.length()>1) {
            return true;
        }
        return false;
    }
    
    public boolean validatePhone(){
        if( phone.matches("[0-9]{8,12}")){  //".*\\d.*"  [0-9]{8,12}
            return true;
        }
        return false;
    }
    
    public boolean validateEmail(){
        if(email.matches("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$")){
            return true;
        }
        return false;
    } 
    
    public boolean validateDOB(){
        if(DOB == null){
            return false;
        }
        return true;
    }
}
