/*
 * This is Data access object
 */  
package control;

import java.sql.*;
import java.util.ArrayList;
import model.*;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class Dao{
    
    protected static String dbClassName = "com.mysql.jdbc.Driver";
    protected static String dbUrl = "jdbc:mysql://localhost:3306/library";
    protected static String dbUser = "root";
    protected static String dbPwd = "Zzc590402";
    protected static String dumpExePath = "C:\\Program Files\\MySQL\\MySQL Server 5.6\\bin\\"; //location where Mysql been installed
    protected static PreparedStatement ps = null;
    protected static Connection conn = null;   
    protected static ResultSet rs = null;
    
    /**
     * Constructor to make the sql server connected and ready to use
     */            
    private Dao(){
        try{
            if (conn == null){
                Class.forName(dbClassName);
                conn = DriverManager.getConnection(dbUrl, dbUser, dbPwd);
            }else{
                return;
            }    
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * close the sql server, release all the resource
     */
    public static void close(){
        try{
            if(conn != null){
                conn.close();
            }
            if(ps != null){
                ps.close();
            }
            if(rs != null){
                rs.close();
            }           
        }catch (SQLException e){
            e.printStackTrace();
        }finally{
            conn = null;
            ps = null;
            rs = null;
        }
    }

    /**
     * execute prepareStatement for insert, delete and modify(update) function,
     * @param sql
     * @param paras
     * @return 
     */
    public static boolean executeUpdate(String sql, String[] paras){
        boolean flag = true;
        
        try{
            if(conn == null){
                new Dao();
            }
            ps = conn.prepareStatement(sql);
            for(int i=0; i<paras.length; i++){
                ps.setString(i+1, paras[i]);
            }
            if(ps.executeUpdate() != 1){
                flag = false;
            }                                       
        }catch(SQLException e){
            flag = false;
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return flag;
    }        
    
    /**
     * execute query for reading from the database
     * @param sql
     * @return result set of reading result
     */
    public static ResultSet executeQuery(String sql){
        try{
            if(conn == null){
                new Dao();
            }
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            return rs;
        }catch(SQLException e){
            e.printStackTrace();
            return null;
        }finally{}
    }

    
    /**
     * database backup
     * @param path path to store the database back file
     * @return true if backup successfully
     */
    public static boolean backup(String path) {
        boolean status = false;
        
        String executeCmd = dumpExePath+"mysqldump -u "+dbUser+ " -p"+dbPwd+
                " --add-drop-database -B library -r "+path;
//        String executeCmd = "mysqldump -u "+dbUser+ " -p"+dbPwd+" library > "+path;
        Process runtimeProcess=null;
        
        try {
            runtimeProcess = Runtime.getRuntime().exec(executeCmd);
            int processComplete = runtimeProcess.waitFor();
            
            if(processComplete == 0){
                status = true;
            }
        } catch (Exception e){
            e.printStackTrace();
        } finally{
            Dao.close();
        }
        
        return status;
    }
    
    /**
     * database restore
     * @param path where to read database file
     * @return true if restore successfully
     */
    public static boolean restore(String path){
        boolean status = false;
        //path to mysql
        String dumpExePath = "C:\\Program Files\\MySQL\\MySQL Server 5.6\\bin\\";
        
        String[] executeCmd = new String[]{dumpExePath+"mysql","--user="+dbUser,"--password="+dbPwd,"-e","source "+path};
        
        Process runtimeProcess=null;
        
        try{
            runtimeProcess = Runtime.getRuntime().exec(executeCmd);
            int processComplete = runtimeProcess.waitFor();
            
            if(processComplete == 0){
                status = true;
            }
        }catch(Exception e){
            e.printStackTrace();
        } finally{
            Dao.close();
        }
        
        return status;
    }
    
    /**
     * check operater login
     * @param name
     * @param password
     * @return the information for current operater
     */
    public static Operater checkLogin(String name, String password){
        Operater operater = new Operater();
        
        try{
            String sql = "select *  from operater where name='" + name
                        + "' and password='" + password + "'";
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                operater.setId(rs.getInt("operaterId"));
                operater.setName(rs.getString("name"));
                operater.setGender(rs.getString("gender"));
                operater.setCreateDate(rs.getString("createDate"));
                operater.setPhoneNo(rs.getString("phoneNo"));
                operater.setAddress(rs.getString("address"));
                operater.setPassword(rs.getString("password"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return operater;
    }
    
    /**
     * get the statistic information about item
     * @param str
     * @return 
     */
    public static String selectItemNum(String str){
        String i = "";
        String sql = "select count(*) from item where itemType = '"+str+"'";
        if(str.isEmpty()){
            sql = "select count(*) from item";
        }
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                i = rs.getString("count(*)");    
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return i;
    }
    
    /**
     * get the statistic information about reader
     * @return 
     */
    public static String selectReaderNum(){
        String i = "";
        String sql = "select count(*) from reader";
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                i = rs.getString("count(*)");
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return i;
    }
    
    /**
     * query book information, return a item list which will be used
     * later for item interface item information table,
     * @param status define the status of item, "A" only show available books,
     *              "UA" only show unavailable books, others show all the books.
     * @return list of book information
     */
    public static ArrayList<Item> selectItem(String status){
        ArrayList<Item> list = new ArrayList();
        String sql = "select * from item";
        if(status.equals("A")){
            sql = "select * from item where status = 'Available'";
        } else if(status.equals("UA")){
            sql = "select * from item where status = 'UA'";
        }
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Item item =new Item();
                item.setId(rs.getString("itemId"));
                item.setType(rs.getString("itemType"));
                item.setIsbn(rs.getString("ISBN"));
                item.setName(rs.getString("name"));
                item.setAuthor(rs.getString("author"));
                item.setPublisher(rs.getString("publisher"));
                item.setPrice(rs.getDouble("price"));
                item.setStatus(rs.getString("status"));
                item.setLocation(rs.getString("location"));
                item.setYears(rs.getString("years"));
                item.setNotes(rs.getString("notes"));
                item.setBindingType(rs.getString("bindingType"));
                item.setCreateDate(rs.getString("createDate"));
                list.add(item);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return list;
    }
    
    /**
     * Method overload.
     * @param status define the status of item.
     * @param readerId item been borrowed under this reader's name.
     * @return list of all book information
     */
    public static ArrayList<Item> selectItem(String status,String readerId){
        ArrayList<Item> list = new ArrayList();
        String sql = "select * from item where status = '"+status+"' and itemId in("
        + "select itemId from item_borrow where readerId = '"+readerId+"' and isBack='N')";
        
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Item item =new Item();
                item.setId(rs.getString("itemId"));
                item.setType(rs.getString("itemType"));
                item.setIsbn(rs.getString("ISBN"));
                item.setName(rs.getString("name"));
                item.setAuthor(rs.getString("author"));
                item.setPublisher(rs.getString("publisher"));
                item.setPrice(rs.getDouble("price"));
                item.setStatus(rs.getString("status"));
                item.setLocation(rs.getString("location"));
                item.setYears(rs.getString("years"));
                item.setNotes(rs.getString("notes"));
                item.setBindingType(rs.getString("bindingType"));
                item.setCreateDate(rs.getString("createDate"));
                list.add(item);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return list;
    }
    
    public static ArrayList<ItemBorrow> selectPopularItem(){
        ArrayList<ItemBorrow> list = new ArrayList();
        String sql = "select itemId, itemName, count(itemId) as count from item_borrow "
                + "group by itemId order by count DESC limit 10";
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                ItemBorrow borrow = new ItemBorrow();
                borrow.setItemID(rs.getString("itemId"));
                borrow.setItemName(rs.getString("itemName"));
                borrow.setBorrowTimes(rs.getString("count"));
                list.add(borrow);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return list;
    }
    
    public static ArrayList<ItemBorrow> selectPopularReader(){
        ArrayList<ItemBorrow> list = new ArrayList();
        String sql = "select readerId, readerName, count(readerId) as count from item_borrow "
                    + "group by readerId order by count DESC limit 10";
      
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                ItemBorrow borrow = new ItemBorrow();
                borrow.setReaderID(rs.getString("readerId"));
                borrow.setReaderName(rs.getString("readerName"));
                borrow.setBorrowTimes(rs.getString("count"));                
                list.add(borrow);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return list;
    }
    
    /**
     * query reader information, return a list of reader which will be used
     * later for reader interface reader information table
     * @return list of all reader information
     */
    public static ArrayList<Reader> selectReader(){
        ArrayList<Reader> list = new ArrayList();
        String sql = "select * from reader";
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Reader reader =new Reader();
                reader.setId(rs.getString("readerId"));
                reader.setName(rs.getString("name"));
                reader.setGender(rs.getString("gender"));
                reader.setDOB(rs.getString("DOB"));
                reader.setPhoneNo(rs.getString("phoneNo"));
                reader.setEmail(rs.getString("email"));
                reader.setAddress(rs.getString("address"));
                reader.setCreateDate(rs.getString("createDate"));
                reader.setNotes(rs.getString("notes"));
                list.add(reader);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return list;
    }
    
    /**
     * query item borrow information, return a list of item which not returned yet
     * @return list of item borrow information under selected reader.
     */
    public static ArrayList<ItemBorrow> selectBorrow(){
        ArrayList<ItemBorrow> list = new ArrayList();
        String sql = "select * from item_borrow where isBack = 'N'";
        try {
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                ItemBorrow borrow = new ItemBorrow();
                borrow.setBorrowID(rs.getString("borrowId"));
                borrow.setReaderID(rs.getString("readerId"));
                borrow.setReaderName(rs.getString("readerName"));
                borrow.setItemID(rs.getString("itemId"));
                borrow.setItemName(rs.getString("itemName"));
                borrow.setOperaterID(rs.getString("operaterId"));
                borrow.setOperaterName(rs.getString("operaterName"));
                borrow.setReturnDate(rs.getString("backTime"));
                borrow.setBorrowDate(rs.getString("borrowTime"));
                list.add(borrow);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            Dao.close();
        }
        
        
        return list;
    }    
    
    /**
     * method overload
     * query item borrow information, return a list of borrow which will be used
     * later for Item ItemBorrow interface borrow information table.
     * @return list of item borrow information under selected reader.
     */
    public static ArrayList<ItemBorrow> selectBorrow(String readerId){
        ArrayList<ItemBorrow> list = new ArrayList();
        String sql = "select * from item_borrow where readerId = '"+readerId+"' and isBack = 'N'";
        try {
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                ItemBorrow borrow = new ItemBorrow();
                borrow.setBorrowID(rs.getString("borrowId"));
                borrow.setReaderID(rs.getString("readerId"));
                borrow.setReaderName(rs.getString("readerName"));
                borrow.setItemID(rs.getString("itemId"));
                borrow.setItemName(rs.getString("itemName"));
                borrow.setOperaterID(rs.getString("operaterId"));
                borrow.setOperaterName(rs.getString("operaterName"));
                borrow.setReturnDate(rs.getString("backTime"));
                borrow.setBorrowDate(rs.getString("borrowTime"));
                list.add(borrow);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            Dao.close();
        }
        
        return list;
    }
 
    /**
     * Search reader by the type user defined
     * @param str key word for search
     * @param type search by which kind of information
     * @return 
     */
    public static ArrayList<Reader> findReaderBy(String str,String type) {
        ArrayList<Reader> list = new ArrayList();
        String sql = "";
        switch(type){
            case "ID":
                sql = "select * from reader where readerId like '%"+str+"%'";
                break;
            case "Name":
                sql = "select * from reader where name like '%"+str+"%'";
                break;
            case "Phone":
                sql = "select * from reader where phoneNo like '%"+str+"%'";
                break;
            case "Email":
                sql = "select * from reader where email like '%"+str+"%'";
                break;
        }
        
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Reader reader =new Reader();
                reader.setId(rs.getString("readerId"));
                reader.setName(rs.getString("name"));
                reader.setGender(rs.getString("gender"));
                reader.setDOB(rs.getString("DOB"));
                reader.setPhoneNo(rs.getString("phoneNo"));
                reader.setEmail(rs.getString("email"));
                reader.setAddress(rs.getString("address"));
                reader.setCreateDate(rs.getString("createDate"));
                reader.setNotes(rs.getString("notes"));
                list.add(reader);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        } 
        
        return list;        
    }
 
    /**
     * Search reader by the itemId reader borrowed from library,
     * One item can only be borrowed by one reader, that is why with itemid, 
     * method return one reader instead of a reader list.
     * @param str key word for search
     * @param type search by which kind of information
     * @return 
     */
    public static Reader findReaderBy(String itemId) {
//        ArrayList<Reader> list = new ArrayList();
        Reader reader = new Reader();
        String sql = "select * from reader where readerId in (select readerId from "
                + "item_borrow where itemId ='"+itemId+"' and isBack = 'N')";
        
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                reader.setId(rs.getString("readerId"));
                reader.setName(rs.getString("name"));
                reader.setGender(rs.getString("gender"));
                reader.setDOB(rs.getString("DOB"));
                reader.setPhoneNo(rs.getString("phoneNo"));
                reader.setEmail(rs.getString("email"));
                reader.setAddress(rs.getString("address"));
                reader.setCreateDate(rs.getString("createDate"));
                reader.setNotes(rs.getString("notes"));
//                list.add(reader);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }
//        return list;   
        return reader;
    }    

    /**
     * Search item by the type and keywords user defined.
     * @param str search keywords.
     * @param type search type.
     * @return 
     */
    public static ArrayList<Item> findItemBy(String str,String type){
        ArrayList<Item> list = new ArrayList();
        String sql = "";
        switch (type){
            case "ISBN":
                sql = "select * from item where ISBN like '%"+str+"%'";
                break;
            case "ID":
                sql = "select * from item where itemId like '%"+str+"%'";
                break;
            case "Name":
                sql = "select * from item where name like '%"+str+"%'";
                break;
            case "Author":
                sql = "select * from item where author like '%"+str+"%'";
                break;
            case "Publisher":
                sql = "select * from item where publisher like '%"+str+"%'";
                break;    
        }
        
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Item item =new Item();
                item.setId(rs.getString("itemId"));
                item.setType(rs.getString("itemType"));
                item.setIsbn(rs.getString("ISBN"));
                item.setName(rs.getString("name"));
                item.setAuthor(rs.getString("author"));
                item.setPublisher(rs.getString("publisher"));
                item.setPrice(rs.getDouble("price"));
                item.setStatus(rs.getString("status"));
                item.setLocation(rs.getString("location"));
                item.setYears(rs.getString("years"));
                item.setNotes(rs.getString("notes"));
                item.setBindingType(rs.getString("bindingType"));
                item.setCreateDate(rs.getString("createDate"));
                list.add(item);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }

        return list;        
    }    
    
    /**
     * Method overload
     * @param str search key words.
     * @param type search type.
     * @param status item status: available or unavailable for borrow.
     * @return 
     */
    public static ArrayList<Item> findItemBy(String str,String type,String status){
        ArrayList<Item> list = new ArrayList();
        String sql = "";
        switch (type){
            case "ISBN":
                if(status.equals("A")){
                    sql = "select * from item where ISBN like '%"+str+"%' and status = 'Available'";
                } else if(status.equals("UA")){
                    sql = "select * from item where ISBN like '%"+str+"%' and status = 'UA'";
                }
                break;
            case "ID":
                if(status.equals("A")){
                    sql = "select * from item where itemId like '%"+str+"%' and status = 'Available'";
                } else if(status.equals("UA")){
                    sql = "select * from item where itemId like '%"+str+"%' and status = 'UA'";
                }
                break;
            case "Name":
                if(status.equals("A")){
                    sql = "select * from item where name like '%"+str+"%' and status = 'Available'";
                } else if(status.equals("UA")){
                    sql = "select * from item where name like '%"+str+"%' and status = 'UA'";
                }
                break;
            case "Author":
                if(status.equals("A")){
                    sql = "select * from item where author like '%"+str+"%' and status = 'Available'";
                } else if(status.equals("UA")){
                    sql = "select * from item where author like '%"+str+"%' and status = 'UA'";
                }
                break;
            case "Publisher":
                if(status.equals("A")){
                    sql = "select * from item where publisher like '%"+str+"%' and status = 'Available'";
                } else if(status.equals("UA")){
                    sql = "select * from item where publisher like '%"+str+"%' and status = 'UA'";
                }
                break;    
        }
        
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Item item =new Item();
                item.setId(rs.getString("itemId"));
                item.setType(rs.getString("itemType"));
                item.setIsbn(rs.getString("ISBN"));
                item.setName(rs.getString("name"));
                item.setAuthor(rs.getString("author"));
                item.setPublisher(rs.getString("publisher"));
                item.setPrice(rs.getDouble("price"));
                item.setStatus(rs.getString("status"));
                item.setLocation(rs.getString("location"));
                item.setYears(rs.getString("years"));
                item.setNotes(rs.getString("notes"));
                item.setBindingType(rs.getString("bindingType"));
                item.setCreateDate(rs.getString("createDate"));
                list.add(item);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }

        return list;        
    }
    
    /**
     * Method overload
     * @param str key word for search
     * @param type search by which kind of information
     * @return 
     */
    public static ArrayList<Item> findItemBy(String str,String type,String status,String readerId){
        ArrayList<Item> list = new ArrayList();
        String sql = "";
        switch (type){
            case "ISBN":
                sql = "select * from item where ISBN like '%"+str+"%' and itemId in (select itemId "
                        + "from item_borrow where readerId ='"+readerId+"' and isBack = 'N')";
                break;
            case "ID":
                sql = "select * from item where itemId like '%"+str+"%' and itemId in (select itemId "
                        + "from item_borrow where readerId ='"+readerId+"' and isBack = 'N')";
                break;
            case "Name":
                sql = "select * from item where name like '%"+str+"%' and itemId in (select itemId "
                        + "from item_borrow where readerId ='"+readerId+"' and isBack = 'N')";
                break;
            case "Author":
                sql = "select * from item where author like '%"+str+"%' and itemId in (select itemId "
                        + "from item_borrow where readerId ='"+readerId+"' and isBack = 'N')";
                break;  
        }
        
        try{
            rs = Dao.executeQuery(sql);
            while(rs.next()){
                Item item =new Item();
                item.setId(rs.getString("itemId"));
                item.setType(rs.getString("itemType"));
                item.setIsbn(rs.getString("ISBN"));
                item.setName(rs.getString("name"));
                item.setAuthor(rs.getString("author"));
                item.setPublisher(rs.getString("publisher"));
                item.setPrice(rs.getDouble("price"));
                item.setStatus(rs.getString("status"));
                item.setLocation(rs.getString("location"));
                item.setYears(rs.getString("years"));
                item.setNotes(rs.getString("notes"));
                item.setBindingType(rs.getString("bindingType"));
                item.setCreateDate(rs.getString("createDate"));
                list.add(item);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
            Dao.close();
        }  

        return list;
    } 
    
    
//    /**
//     * make sure same operater name will not be used twice
//     * @param name
//     * @return 
//     */
//    public static boolean checkOperaterName(String name){
//        try{
//            String sql = "select *  from operater where name='" + name + "'";
//            rs = Dao.executeQuery(sql);
//            if(!rs.next()){
//                return true;
//            } 
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return false;
//    }
    
//    /**
//     * execute sql query
//     * @param sql
//     * @return result set of the query
//     */
//    private static ResultSet executeQuery(String sql){
//        try{
//            if(conn==null){
//                new Dao();
//            }
//            return conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE).executeQuery(sql);
//        }catch(SQLException e){
//            e.printStackTrace();
//            return null;
//        } finally {
//        }
//    }
    
//    /**
//     * execute the sql update 
//     * @param sql
//     * @return 1 update succeed or 0 nothing happened
//     */
//    private static int executeUpdate(String sql) {
//        try{
//            if(conn==null){
//                new Dao();
//            }       
//            return conn.createStatement().executeUpdate(sql);
//        } catch (SQLException e){
//            System.out.println(e.getMessage());
//            return -1;
//        } finally {
//        }
//    }
   
//    /**
//     * Insert these information into item table
//     * @param isbn
//     * @param name 
//     * @param author
//     * @param publisher
//     * @param price
//     * @param location
//     * @return 
//     */
//    public static int insertItem(String type, String isbn, String name, String author, String publisher, double price, String location){
//        int i = 0;
//        try{
//            String sql = "insert into item(itemType,ISBN,name,author,publisher,price,location) values "
//            + "('"+type+"','"+isbn+"','"+name+"','"+author+"','"+publisher+"',"+price+",'"+location+"')";
//            
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return i;
//    }
    
//    /**
//     * Insert these information into reader table
//     * @param name
//     * @param gender
//     * @param dob
//     * @param phone
//     * @param email
//     * @param address
//     * @param createDate
//     * @return 
//     */
//    public static int insertReader(String name, String gender, String dob, String phone, String email, String address, String createDate){
//        int i = 0;
//        try{
//            String sql = "insert into reader(name,gender,DOB,phoneNo,email,address,createDate) values "
//            + "('"+name+"','"+gender+"','"+dob+"','"+phone+"','"+email+"','"+address+"','"+createDate+"')";
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//            
//        return i;
//    }
    
//    /**
//     * insert these information into operater table
//     * @param name
//     * @param gender
//     * @param createDate
//     * @param phone
//     * @param address
//     * @param password
//     * @return 
//     */
//    public static int insertOperater(String name, String gender, String createDate, String phone, String address, String password) {
//        int i = 0;
//        try{
//            String sql = "insert into operater(name,gender,createDate,phoneNo,address,password) values "
//            + "('"+name+"','"+gender+"','"+createDate+"','"+phone+"','"+address+"','"+password+"')";
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//            
//        return i;
//    }
    
//    /**
//     * Delete from reader table where readerId = parameter
//     * @param readerId
//     * @return 
//     */
//    public static int deleteReader(String readerId) {
//        int i = 0;
//        try{
//            String sql = "delete from reader where readerId = '"+readerId+"'";
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return i;
//    }
    
//    /**
//     * Delete from book table where ISBN = parameter
//     * @param ISBN
//     * @return 
//     */
//    public static int deleteItem(String id) {
//        int i = 0;
//        try{
//            String sql = "delete from item where itemId = '"+id+"'";
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return i;
//    } 
    
//    /**
//     * update reader table, when operater modified reader information
//     * @param id
//     * @param name
//     * @param gender
//     * @param dob
//     * @param phone
//     * @param email
//     * @param address
//     * @return 
//     */
//    public static int updateReader(String id, String name, String gender, String dob, String phone, String email, String address){
//        int i = 0;
//        try{
//            String sql = "update reader set name ='"+name+"',gender='"+gender+"',DOB='"+dob+"',phoneNo='"+phone
//            + "',email='"+email+"',address='"+address+"' where readerId="+Integer.parseInt(id);
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return i;
//    }
    
//    /**
//     * update book table, when operater modified book information
//     * @param isbn
//     * @param name
//     * @param author
//     * @param publisher
//     * @param price
//     * @param location
//     * @return 
//     */
//    public static int executeUpdate(String id, String type, String isbn, String name, String author, String publisher, double price, String location) {
//        int i = 0;
//        try{
//            String sql = "update item set itemType ='"+type+"',ISBN='"+isbn+"',name='"+name+"',author='"+author+"',publisher='"+
//            publisher+"',price="+price+",location='"+location+"' where itemId ="+Integer.parseInt(id);
//            
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return i;
//    }
    
//    /**
//     * update operater password, when operater want to change
//     * @param pwd   new password
//     * @param name  operater name
//     * @return 
//     */
//    public static int updatePassword(String pwd, String name){
//        int i = 0;
//        try{
//            String sql = "update operater set password = '"+pwd+"' where name ='"+name+"'";
//            i = Dao.executeUpdate(sql);
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();
//        
//        return i;
//    }
    
//    /**
//     * Search reader by reader Id
//     * @param id
//     * @return 
//     */
//    public static ArrayList<Reader> findReaderById(String id) {
//        ArrayList<Reader> list = new ArrayList();
//        try{
//            String sql = "select * from reader where readerId like '%"+id+"%'";
//            ResultSet rs = Dao.executeQuery(sql);
//            while(rs.next()){
//                Reader reader =new Reader();
//                reader.setId(rs.getInt("readerId"));
//                reader.setName(rs.getString("name"));
//                reader.setGender(rs.getString("gender"));
//                reader.setDOB(rs.getString("DOB"));
//                reader.setPhoneNo(rs.getString("phoneNo"));
//                reader.setEmail(rs.getString("email"));
//                reader.setAddress(rs.getString("address"));
//                reader.setCreateDate(rs.getString("createDate"));
//                list.add(reader);
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();   
//        
//        return list;
//    }
    

    
//    /**
//     * Search item by item ID
//     * @param id
//     * @return 
//     */
//    public static ArrayList<Item> findItemById(String id) {
//        ArrayList<Item> list = new ArrayList();
//        try{
//            String sql = "select * from item where itemId like '%"+id+"%'";
//            ResultSet rs = Dao.executeQuery(sql);
//            while(rs.next()){
//                Item item =new Item();
//                item.setId(rs.getString("itemId"));
//                item.setType(rs.getString("itemType"));
//                item.setIsbn(rs.getString("ISBN"));
//                item.setName(rs.getString("name"));
//                item.setAuthor(rs.getString("author"));
//                item.setPublisher(rs.getString("publisher"));
//                item.setPrice(rs.getDouble("price"));
//                item.setStatus(rs.getString("status"));
//                item.setLocation(rs.getString("location"));
//                list.add(item);
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();   
//        
//        return list;        
//    }    
    
//    /**
//     * Search item by item name
//     * @param name
//     * @return 
//     */
//    public static ArrayList<Item> findItemByName(String name) {
//        ArrayList<Item> list = new ArrayList(); 
//        try{
//            String sql = "select * from item where name like '%"+name+"%'";
//            ResultSet rs = Dao.executeQuery(sql);
//            while(rs.next()){
//                Item item =new Item();
//                item.setId(rs.getString("itemId"));
//                item.setType(rs.getString("itemType"));
//                item.setIsbn(rs.getString("ISBN"));
//                item.setName(rs.getString("name"));
//                item.setAuthor(rs.getString("author"));
//                item.setPublisher(rs.getString("publisher"));
//                item.setPrice(rs.getDouble("price"));
//                item.setStatus(rs.getString("status"));
//                item.setLocation(rs.getString("location"));
//                list.add(item);
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();   
//        
//        return list;        
//    }
    
//    /**
//     * Search item by its author name
//     * @param author
//     * @return 
//     */
//    public static ArrayList<Item> findItemByAuthor(String author) {
//        ArrayList<Item> list = new ArrayList(); 
//        try{
//            String sql = "select * from item where author like '%"+author+"%'";
//            ResultSet rs = Dao.executeQuery(sql);
//            while(rs.next()){
//                Item item =new Item();
//                item.setId(rs.getString("itemId"));
//                item.setType(rs.getString("itemType"));
//                item.setIsbn(rs.getString("ISBN"));
//                item.setName(rs.getString("name"));
//                item.setAuthor(rs.getString("author"));
//                item.setPublisher(rs.getString("publisher"));
//                item.setPrice(rs.getDouble("price"));
//                item.setStatus(rs.getString("status"));
//                item.setLocation(rs.getString("location"));
//                list.add(item);
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();   
//        
//        return list;        
//    }    
    
//    /**
//     * Search item by its publisher name
//     * @param publisher
//     * @return 
//     */
//    public static ArrayList<Item> findItemByPublisher(String publisher) {
//        ArrayList<Item> list = new ArrayList();
//        try{
//            String sql = "select * from item where publisher like '%"+publisher+"%'";
//            ResultSet rs = Dao.executeQuery(sql); 
//            while(rs.next()){
//                Item item =new Item();
//                item.setId(rs.getString("itemId"));
//                item.setType(rs.getString("itemType"));
//                item.setIsbn(rs.getString("ISBN"));
//                item.setName(rs.getString("name"));
//                item.setAuthor(rs.getString("author"));
//                item.setPublisher(rs.getString("publisher"));
//                item.setPrice(rs.getDouble("price"));
//                item.setStatus(rs.getString("status"));
//                item.setLocation(rs.getString("location"));
//                list.add(item);
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//        Dao.close();   
//        
//        return list;        
//    }    
}
