/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class ItemBorrow {
    private String borrowID,borrowDate, itemID, itemName, readerID, readerName, returnDate, operaterID,operaterName, borrowTimes;

    public String getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowTimes(String borrowTimes) {
        this.borrowTimes = borrowTimes;
    }

    public String getBorrowTimes() {
        return borrowTimes;
    }

    public void setBorrowID(String borrowID) {
        this.borrowID = borrowID;
    }

    public String getBorrowID() {
        return borrowID;
    }

    public String getItemID() {
        return itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public String getReaderID() {
        return readerID;
    }

    public String getReaderName() {
        return readerName;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public String getOperaterName() {
        return operaterName;
    }

    public String getOperaterID() {
        return operaterID;
    }

    public void setOperaterID(String operaterID) {
        this.operaterID = operaterID;
    }

    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setReaderID(String readerID) {
        this.readerID = readerID;
    }

    public void setReaderName(String readerName) {
        this.readerName = readerName;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public void setOperaterName(String operaterName) {
        this.operaterName = operaterName;
    }
}
