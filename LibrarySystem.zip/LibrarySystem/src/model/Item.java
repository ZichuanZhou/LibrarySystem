/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class Item {
    
    private String type, id, isbn, name, author, publisher, status,location,
            notes, bindingType, years, createDate;
    private double price;

    public String getId() {
        return id;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public void setBindingType(String bindingType) {
        this.bindingType = bindingType;
    }

    public void setYears(String years) {
        this.years = years;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getNotes() {
        return notes;
    }

    public String getBindingType() {
        return bindingType;
    }

    public String getYears() {
        return years;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getStatus() {
        return status;
    }

    public double getPrice() {
        return price;
    }

    public String getLocation() {
        return location;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
