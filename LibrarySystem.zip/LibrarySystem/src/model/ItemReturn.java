/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Zichuan Zhou <hero_zzc@hotmail.com>
 */
public class ItemReturn {
    private String itemID, itemName, readerID, readerName, returnDate, operaterID,operaterName;

    public String getItemID() {
        return itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public String getReaderID() {
        return readerID;
    }

    public String getReaderName() {
        return readerName;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public String getOperaterID() {
        return operaterID;
    }

    public String getOperaterName() {
        return operaterName;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setReaderID(String readerID) {
        this.readerID = readerID;
    }

    public void setReaderName(String readerName) {
        this.readerName = readerName;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public void setOperaterID(String operaterID) {
        this.operaterID = operaterID;
    }

    public void setOperaterName(String operaterName) {
        this.operaterName = operaterName;
    }
}
